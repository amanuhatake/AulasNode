//#
//Importar o expressa 
const express = require ('express');
const app = express(); //instanciando o express
const port = 3000;


//#
//Configurando o Middlewares
app.use(express.urlencoded({extended: true}));
app.use(express.json()); // json vai ser manipulado pelo express, formatar e etc

//Configurando um ejs 
//configurando servidor
app.set('view engine', 'ejs');
//Configuração OPCIONAL
app.set('views', './src/views') //mostrando para o ejs aonde pegar/procurar no diretório e raiz do projeto

//criando rota
//Renderizando a página HTML/EJS diretamente
app.get(`/`,(req, res)=>{
    const NOMESISTEMA = "SysManu";
    res.render('index', {nome: NOMESISTEMA});//objeto conceito de chaves e valores, passando pro ejs o objeto com o valor
})

app.get('/carros', (req,res) =>{
    let cars = [
        {id: 1, marca: 'GM',modelo: 'Corsa', },
        {id: 2, marca: 'VW',modelo: 'GOL', },
        {id: 3, marca: 'Toyota',modelo: 'Corolla', },
        {id: 4, marca: 'VW',modelo: 'Limao8', },
        {id: 5, marca: 'Renault',modelo: 'Duster', },
        {id: 6, marca: 'Ferrari',modelo: '712', },
    ]

    res.render('list_carros',{listaCarros: cars});
})

app.get('/motos', (req,res)=>{
    const MOTOS = [
        {id: 1, marca: 'HONDA', modelo: 'Titan'},
        {id: 2, marca: 'HONDA', modelo: 'Fan'},
        {id: 3, marca: 'BMW', modelo: 'F900R'},
        {id: 4, marca: 'HONDA', modelo: 'BIZ'},
        {id: 5, marca: 'Yamaha', modelo: 'MT09'},
        {id: 4, marca: 'Ducati', modelo: '821'},
        {id: 4, marca: 'HONDA', modelo: 'Z900'},
    ]

    res.render('list_motos', {LISTA_DE_MOTOS: MOTOS});
})


//#
//Inicializando o servidor
//socket host+ip+porta consigo acessar o recurso dentro do servidor
app.listen(port, ()=>{
    console.log(`Servidor rodando na porta ${port}`);
}) 